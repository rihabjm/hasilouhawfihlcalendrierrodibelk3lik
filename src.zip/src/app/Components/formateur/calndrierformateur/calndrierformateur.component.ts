import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calndrierformateur',
  templateUrl: './calndrierformateur.component.html',
  styleUrls: ['./calndrierformateur.component.scss']
})
export class CalndrierformateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
