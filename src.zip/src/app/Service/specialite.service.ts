import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Specilaite} from '../Model/Specilaite';
import {Formation} from '../Model/Formation';
@Injectable({
  providedIn: 'root'
})
export class SpecialiteService {
  private url = Config.BASE_URL + '/Specialite';
  private urldetail =this.url+'/byid';
  constructor(private httpClient: HttpClient) { }

    add(specialite: Specilaite): Observable<object> {
    return this.httpClient.post(this.url + '/add', specialite);
  }

  list(): Observable<any> {
    return this.httpClient.get(this.url + '/get', );
  }
  public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetail }/${id}`);
   }

  public getformateurs(formation :any): Observable<any> {
    return this.httpClient.get(this.url+'/bycategorie/'+formation);
  }


}













