import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistreComponent } from './registre/registre.component';
import { LoginregistreComponent } from './loginregistre/loginregistre.component';

import { ModifprofilComponent } from './modifprofil/modifprofil.component';
import { ModifmdpComponent } from './modifmdp/modifmdp.component';
const routes: Routes = [
{
         path: 'loginregistre',component: LoginregistreComponent,
        children: [
            { path: 'login', component: LoginComponent} ,
            { path: 'registre', component: RegistreComponent } ,
            { path: 'modifmdp', component: ModifmdpComponent } ,
            { path: 'modifprofil', component: ModifprofilComponent } ,
                   ]
                       }


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginregistreRoutingModule { }
