import { TestBed } from '@angular/core/testing';

import { RemiseService } from './remise.service';

describe('RemiseService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RemiseService = TestBed.get(RemiseService);
    expect(service).toBeTruthy();
  });
});
