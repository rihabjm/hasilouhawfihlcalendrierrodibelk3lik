import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AjoutsalleComponent } from './ajoutsalle/ajoutsalle.component';
import { SupprimesalleComponent } from './supprimesalle/supprimesalle.component';
import { ListsalleComponent } from './listsalle/listsalle.component';
import { ModifiersalleComponent } from './modifiersalle/modifiersalle.component';
import { SalleComponent } from './salle/salle.component';

const routes: Routes = [{
         path: 'salle',component: SalleComponent,
        children: [
            { path: 'ajoutersalle', component: AjoutsalleComponent} ,
            { path: 'modifiersalle', component: ModifiersalleComponent } ,
            { path: 'supprimersalle', component: SupprimesalleComponent } ,
            { path: 'listersalle', component: ListsalleComponent } ,
                   ]
                       }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalleRoutingModule { }
