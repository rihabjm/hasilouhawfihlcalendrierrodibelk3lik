import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Khademni} from '../Model/khademni';
@Injectable({
  providedIn: 'root'
})
export class KhademniServiceService {
constructor( ) { }


}
