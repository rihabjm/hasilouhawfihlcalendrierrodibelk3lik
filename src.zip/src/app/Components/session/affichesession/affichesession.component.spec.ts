import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AffichesessionComponent } from './affichesession.component';

describe('AffichesessionComponent', () => {
  let component: AffichesessionComponent;
  let fixture: ComponentFixture<AffichesessionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AffichesessionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AffichesessionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
