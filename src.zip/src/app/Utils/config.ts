export class Config {
   public  static  BASE_URL = 'http://localhost:9028';

}
