import {AfterViewInit, Component, ViewChild , OnInit } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import { Router } from '@angular/router';
import { DetatilsformateurComponent } from '../detatilsformateur/detatilsformateur.component';

import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-listformateur',
  templateUrl: './listformateur.component.html',
  styleUrls: ['./listformateur.component.scss']
})
export class ListformateurComponent implements OnInit {

  //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatSort) sort: MatSort;

name: string;
  position: number;
  weight: number;
  symbol: string;

message :String ;

  constructor(private formateurservice :FormateurService ,private router: Router ,private _Activatedroute:ActivatedRoute)
{

}

  ngOnInit() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur =data ;
    }, ex => {
      console.log(ex);
    });

this.getAll() ;
  }

formateur: Formateur[] = new Array();



private getAll() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur=data ;
    }, ex => {
      console.log(ex);
    });}

 Detailsformateur(id: number){
    this.router.navigate(['details', id]);
  }





delete(id: number) {

    this.formateurservice.delete(id).subscribe(data => {
      if (data.success) {

     this.message="formateur supprimer"
      this.getAll();


} else {
this.message="erreur de suppresion" ;
  }

    }, ex => {

     console.log(ex);
    });
  }


private getAllFormateurById(id : String) {
 this.formateurservice.getUserById(id).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}


private getAllFormateurByNom(nom : String) {
 this.formateurservice.getUserByNom(nom).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByPrenom(prenom : String) {
 this.formateurservice.getUserByPrenom(prenom).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByAdresse(adresse : String) {
 this.formateurservice.getUserByAdresse(adresse).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByTelephone(telephone : String) {
 this.formateurservice.getUserByTelephone(telephone).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByGmail(gmail : String) {
 this.formateurservice.getUserByGmail(gmail).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByDateNAisse(datenaisse : String) {
 this.formateurservice.getUserByDateNAisse(datenaisse).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurBySexe(sexe : String) {
 this.formateurservice.getUserBySexe(sexe).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByFacebook(facebook : String) {
 this.formateurservice.getUserByFacebook(facebook).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

private getAllFormateurByLinked(linked : String) {
 this.formateurservice.getUserByLinked(linked).subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}



}
