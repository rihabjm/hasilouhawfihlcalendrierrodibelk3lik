import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listsalle',
  templateUrl: './listsalle.component.html',
  styleUrls: ['./listsalle.component.scss']
})
export class ListsalleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
